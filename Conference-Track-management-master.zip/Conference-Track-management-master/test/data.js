
module.exports = {
    "sessions": [
    {"duration": 60, "title": "Writing Fast Tests against Enterprise Rails"},
    {"duration": 45, "title": "Overdoing it in Python"},
    {"duration": 30, "title": "Lua for masses"},
    {"duration": 45, "title": "Ruby errors from mismatched gem vrsions"},
    {"duration": 45, "title": "Common Ruby Errors"},
    {"duration": 60, "title": "Rails for Python developers lightning communication over distance"},
    {"duration": 45, "title": "Accounting driven development"},
    {"duration": 30, "title": "Woah"},
    {"duration": 30, "title": "Sit down and write"},
    {"duration": 45, "title": "Pair programming vs Noise"},
    {"duration": 60, "title": "Rails Magic"},
    {"duration": 60, "title": "Ruby on rails: Why we should move on"},
    {"duration": 45, "title": "Clojure ate scala"},
    {"duration": 30, "title": "Programming in Boondocks of Seattle"},
    {"duration": 30, "title": "Ruby vs Clojure for backend development"},
    {"duration": 60, "title": "Ruby on Rails legacy App maintenance"},
    {"duration": 30, "title": "A world without Hacker News"},
    {"duration": 30, "title": "User Interface CSS in Rails Apps"}
]
}