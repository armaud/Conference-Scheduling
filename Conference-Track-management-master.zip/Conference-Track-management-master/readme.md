
**CONFERENCE TRACK SCHEDULING**

**Readme**
##
-- ***** Steps to initialize node server
## npm i
## npm start

**INFO**
change data from following file 
## test/data.js
